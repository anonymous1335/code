To run simulations:
1. install environments using conda from environment.yaml
2. run attack/runsim.py