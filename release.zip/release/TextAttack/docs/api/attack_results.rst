Attack Result API Reference
============================

AttackResult
-------------
.. autoclass:: textattack.attack_results.AttackResult
   :members:

SuccessfulAttackResult
-----------------------
.. autoclass:: textattack.attack_results.SuccessfulAttackResult
   :members:

FailedAttackResult
-----------------------
.. autoclass:: textattack.attack_results.FailedAttackResult
   :members:

SkippedAttackResult
-----------------------
.. autoclass:: textattack.attack_results.SkippedAttackResult
   :members:

MaximizedAttackResult
-----------------------
.. autoclass:: textattack.attack_results.MaximizedAttackResult
   :members:
