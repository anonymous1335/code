Constraints API Reference
============================

Constraint
------------
.. autoclass:: textattack.constraints.Constraint
   :members:

PreTransformationConstraint
-----------------------------
.. autoclass:: textattack.constraints.PreTransformationConstraint
    :members:

