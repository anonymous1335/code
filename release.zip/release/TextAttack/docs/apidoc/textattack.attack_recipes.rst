textattack.attack\_recipes package
==================================

.. automodule:: textattack.attack_recipes
   :members:
   :undoc-members:
   :show-inheritance:



.. automodule:: textattack.attack_recipes.attack_recipe
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.bae_garg_2019
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.bert_attack_li_2020
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.checklist_ribeiro_2020
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.clare_li_2020
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.deepwordbug_gao_2018
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.faster_genetic_algorithm_jia_2019
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.genetic_algorithm_alzantot_2018
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.hotflip_ebrahimi_2017
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.iga_wang_2019
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.input_reduction_feng_2018
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.kuleshov_2017
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.morpheus_tan_2020
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.pruthi_2019
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.pso_zang_2020
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.pwws_ren_2019
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.seq2sick_cheng_2018_blackbox
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.textbugger_li_2018
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.attack_recipes.textfooler_jin_2019
   :members:
   :undoc-members:
   :show-inheritance:
