textattack.goal\_function\_results package
==========================================

.. automodule:: textattack.goal_function_results
   :members:
   :undoc-members:
   :show-inheritance:



.. automodule:: textattack.goal_function_results.classification_goal_function_result
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.goal_function_results.goal_function_result
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.goal_function_results.text_to_text_goal_function_result
   :members:
   :undoc-members:
   :show-inheritance:
