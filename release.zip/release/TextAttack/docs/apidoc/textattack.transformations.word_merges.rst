textattack.transformations.word\_merges package
===============================================

.. automodule:: textattack.transformations.word_merges
   :members:
   :undoc-members:
   :show-inheritance:



.. automodule:: textattack.transformations.word_merges.word_merge
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.transformations.word_merges.word_merge_masked_lm
   :members:
   :undoc-members:
   :show-inheritance:
