textattack.goal\_functions.classification package
=================================================

.. automodule:: textattack.goal_functions.classification
   :members:
   :undoc-members:
   :show-inheritance:



.. automodule:: textattack.goal_functions.classification.classification_goal_function
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.goal_functions.classification.input_reduction
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.goal_functions.classification.targeted_classification
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: textattack.goal_functions.classification.untargeted_classification
   :members:
   :undoc-members:
   :show-inheritance:
