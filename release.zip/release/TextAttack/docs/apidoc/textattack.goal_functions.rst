textattack.goal\_functions package
==================================

.. automodule:: textattack.goal_functions
   :members:
   :undoc-members:
   :show-inheritance:



.. toctree::
   :maxdepth: 6

   textattack.goal_functions.classification
   textattack.goal_functions.text



.. automodule:: textattack.goal_functions.goal_function
   :members:
   :undoc-members:
   :show-inheritance:
