textattack.metrics package
==========================

.. automodule:: textattack.metrics
   :members:
   :undoc-members:
   :show-inheritance:



.. toctree::
   :maxdepth: 6

   textattack.metrics.attack_metrics
   textattack.metrics.quality_metrics



.. automodule:: textattack.metrics.metric
   :members:
   :undoc-members:
   :show-inheritance:
